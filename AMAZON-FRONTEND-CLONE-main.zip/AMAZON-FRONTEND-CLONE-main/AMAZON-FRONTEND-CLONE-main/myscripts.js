function
addtocart1 ()
{


  const myElement = document.getElementById ("1").value;

  var my = sessionStorage.getItem (myElement);
  var myElement1=Number(my);
	console.log(myElement1);
  if (myElement == null)
	{

	  myElement1 = 0;

	}

  else
	{

	  myElement1 += 1;

	}

  alert (myElement + " added successfully\n Quantity : " + myElement1 + " " 
		 );

  sessionStorage.setItem (myElement, myElement1);

  let data = sessionStorage.getItem (myElement);
  cartcount();

}

function
addtocart2 ()
{


  const myElement = document.getElementById ("2").value;

  var my = sessionStorage.getItem (myElement);
  var myElement1=Number(my);
	console.log(myElement1);
  if (myElement == null)
	{

	  myElement1 = 0;

	}

  else
	{

	  myElement1 += 1;

	}

  alert (myElement + " added successfully\n Quantity : " + myElement1 + " " 
		 );

  sessionStorage.setItem (myElement, myElement1);

  let data = sessionStorage.getItem (myElement);
  cartcount();

}
function
addtocart3 ()
{


  const myElement = document.getElementById ("3").value;

  var my = sessionStorage.getItem (myElement);
  var myElement1=Number(my);
	console.log(myElement1);
  if (myElement == null)
	{

	  myElement1 = 0;

	}

  else
	{

	  myElement1 += 1;

	}

  alert (myElement + " added successfully\n Quantity : " + myElement1 + " " 
		 );

  sessionStorage.setItem (myElement, myElement1);

  let data = sessionStorage.getItem (myElement);
  cartcount();

}
function
addtocart4 ()
{


  const myElement = document.getElementById ("4").value;

  var my = sessionStorage.getItem (myElement);
  var myElement1=Number(my);
	console.log(myElement1);
  if (myElement == null)
	{

	  myElement1 = 0;

	}

  else
	{

	  myElement1 += 1;

	}

  alert (myElement + " added successfully\n Quantity : " + myElement1 + " " 
		 );

  sessionStorage.setItem (myElement, myElement1);

  let data = sessionStorage.getItem (myElement);
  cartcount();

}
function
addtocart5()
{


  const myElement = document.getElementById ("5").value;

  var my = sessionStorage.getItem (myElement);
  var myElement1=Number(my);
	console.log(myElement1);
  if (myElement == null)
	{

	  myElement1 = 0;

	}

  else
	{

	  myElement1 += 1;

	}

  alert (myElement + " added successfully\n Quantity : " + myElement1 + " " 
		 );

  sessionStorage.setItem (myElement, myElement1);

  let data = sessionStorage.getItem (myElement);
  cartcount();

}
function
addtocart6 ()
{


  const myElement = document.getElementById ("6").value;

  var my = sessionStorage.getItem (myElement);
  var myElement1=Number(my);
	console.log(myElement1);
  if (myElement == null)
	{

	  myElement1 = 0;

	}

  else
	{

	  myElement1 += 1;

	}

  alert (myElement + " added successfully\n Quantity : " + myElement1 + " " 
		 );

  sessionStorage.setItem (myElement, myElement1);

  let data = sessionStorage.getItem (myElement);
  cartcount();
}

function cartcount(){
  var m=0;
  for (var i = 0; i < sessionStorage.length; i++) {
    var key = sessionStorage.key(i);
    var value = sessionStorage.getItem(key);
    value=Number(value);
    m+=value;
  }
  document.getElementById("cartCircle").innerText = m;

}

window.onload = cartcount;

